package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class CreateLead extends ProjectSpecificMethods{
	
	
	public CreateLead(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public CreateLead enterCompanyname(String companyName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
        return this;
	}
	public CreateLead enterFirstname(String firstName) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
       return this;
	}
	public CreateLead enterLastname(String lastName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
        return this;
	}
	public ViewLeadsPage clickCreateLeadsSubmitbutton() {
		driver.findElement(By.name("submitButton")).click();
		return new ViewLeadsPage(driver);

	}

}
