package constructorLearning;

public class LearnConstructor {
	
	int empId;
	String empName;
    boolean	empStatus;
    
    //syntax for default constructor
    public LearnConstructor() {
    	System.out.println("Default Constructor");
    	
    }
    
    
    //syntax for parameterised constructor
    public LearnConstructor(int empId,String empName,boolean empStatus) {
    	this();
    	System.out.println("Parameterised Constructor");
    	this.empId=empId;
    	this.empName=empName;
    	this.empStatus=empStatus;
    }
	
	
    public static void main(String[] args) {
//	LearnConstructor lc=new LearnConstructor();
//		System.out.println(lc.empId);
//		System.out.println(lc.empName);
//       System.out.println(lc.empStatus);
       
       LearnConstructor lc1=new LearnConstructor(21, "Balaji", false);
       System.out.println(lc1.empId);
       System.out.println(lc1.empName);
       System.out.println(lc1.empStatus);
	}

}
