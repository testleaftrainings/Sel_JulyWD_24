package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class ProjectSpecificMethods extends AbstractTestNGCucumberTests {
	//public static ChromeDriver driver;
	public String fileName;
	public static Properties prop;
	
	private static final ThreadLocal<ChromeDriver> cDriver=new ThreadLocal<ChromeDriver>();
	
	public void setDriver() {
		cDriver.set(new ChromeDriver());
	}
	
	public ChromeDriver getDriver() {
		return cDriver.get();
	}
	
 @BeforeMethod
	public void preCondition() throws IOException {
	 
	    FileInputStream fis=new FileInputStream("src/test/resources/config.fr.properties");
		
		prop=new Properties();
		
		prop.load(fis);
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps");
		getDriver().manage().window().maximize();

	}
	
@DataProvider
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(fileName);

	}
	@AfterMethod
	public void postCondition() {
		getDriver().close();

	}

}
