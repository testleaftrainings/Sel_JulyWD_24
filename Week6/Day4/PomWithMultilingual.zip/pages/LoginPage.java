package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethods {
	
	
	@And("Enter the username as {string}")
	public LoginPage enterUserame(String username) {
		String user = prop.getProperty("username");
		getDriver().findElement(By.id("username")).sendKeys(user);
         return this;		

	}
	@And("Enter the password as {string}")
	public LoginPage enterPassword(String password) {
		String pass = prop.getProperty("password");
		getDriver().findElement(By.id("password")).sendKeys(pass);
		return this;

	}
	
	@When("Click on the Login button")
	public WelcomePage clickLogin() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
        return new WelcomePage();
	}

}
