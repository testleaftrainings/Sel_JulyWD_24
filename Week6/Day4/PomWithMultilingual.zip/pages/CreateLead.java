package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CreateLead extends ProjectSpecificMethods{
	
	
	
	@Given("Enter the companyname as (.*)$")
	public CreateLead enterCompanyname(String companyName) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
        return this;
	}
	
	@Given("Enter the firstname as (.*)$")
	public CreateLead enterFirstname(String firstName) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
       return this;
	}
	
	@Given("Enter the lastname as (.*)$")
	public CreateLead enterLastname(String lastName) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
        return this;
	}
	@When("Click on the CreateLead submit button")
	public ViewLeadsPage clickCreateLeadsSubmitbutton() {
		getDriver().findElement(By.name("submitButton")).click();
		return new ViewLeadsPage();

	}

}
