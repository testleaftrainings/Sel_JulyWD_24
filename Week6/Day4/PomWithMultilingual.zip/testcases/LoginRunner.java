package testcases;

import base.ProjectSpecificMethods;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features="./src/main/java/feature", glue="pages",monochrome=true,publish=true)
public class LoginRunner extends ProjectSpecificMethods{

}
