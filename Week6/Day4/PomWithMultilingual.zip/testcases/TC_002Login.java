package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;
import utils.ReadExcel;

public class TC_002Login extends ProjectSpecificMethods {
	
	
    @BeforeTest
	public void setValues() {
		fileName="Login";

	}
	
	
	
	@Test(dataProvider="sendData")  //[0][1]
	public void runLogin(String username, String password) {
		
		LoginPage lp=new LoginPage();
		lp.enterUserame(username)
		.enterPassword(password)
		.clickLogin()
         .verifyLogin();
         
	}

}
