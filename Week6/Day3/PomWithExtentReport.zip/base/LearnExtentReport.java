package base;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {
		
		//Mandatory steps - common steps
		
		//Step1:setup the path for the reports folder
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/result.html");

		//Step 2: Create object for ExtentReports
		ExtentReports extent=new ExtentReports();
		
		//Step3:Attach the data with the file
		extent.attachReporter(reporter);
		
		//Step4: Create the testcases and assign details for each testcases
		ExtentTest test = extent.createTest("CreateLead", "Create Lead with multiple data");
		test.assignAuthor("Vineeth");
		test.assignCategory("Regression");
		
		//Step4:add the step level status
		test.pass("Username is entered successfully",MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/username.jpeg").build());
		test.pass("Password is entered successfully");
		test.pass("Login Button is clicked successfully");
		
		//Step6: flush();
		
		extent.flush();  //mandatory step
		
		System.out.println("Done");
	}

}
