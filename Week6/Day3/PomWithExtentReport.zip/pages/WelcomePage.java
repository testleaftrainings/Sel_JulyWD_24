package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends ProjectSpecificMethods{
	
	
	@Then("It should navigate to the welcome page")
	public WelcomePage verifyLogin() {
		String welcomeText = driver.findElement(By.xpath("//h2[text()='Welcome ']")).getText();

		if (welcomeText.contains("Welcome")) {
			System.out.println("The page was navigated");
		}
		else
		{
			System.out.println("The page was not navigated");
		}
		return this;

	}
	
	@When("Click the crmsfa link")
	public MyHomePage clickCrmsfa() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();

	}

}
