package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;
import utils.ReadExcel;

public class TC_001CreateLead extends ProjectSpecificMethods {
	@BeforeTest
	public void setValues() {
		fileName="CreateLead";

	}
	
	
    @Test(dataProvider="sendData")
	public void runCreateLead(String username,String password, String companyName,String firstName,String lastName ) {
		
		LoginPage lp=new LoginPage();
		lp.enterUserame(username)
		.enterPassword(password)
		.clickLogin()
         .verifyLogin()
         .clickCrmsfa()
         .clickLeads()
         .clickCreateLeads()
         .enterCompanyname(companyName)
         .enterFirstname(firstName)
         .enterLastname(lastName)
         .clickCreateLeadsSubmitbutton()
         .verifyLead();
	}

}
