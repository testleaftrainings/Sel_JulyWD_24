package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.When;

public class MyLeadsPage extends ProjectSpecificMethods {
	
	
	@When("Click the CreateLead link")
	
	public CreateLead clickCreateLeads() {
		getDriver().findElement(By.linkText("Create Lead")).click();
	    return new CreateLead();

	}

}
