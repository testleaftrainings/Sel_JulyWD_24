package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.When;

public class MyHomePage extends ProjectSpecificMethods {
	
	
	@When("Click the Leads link")
	
	public MyLeadsPage clickLeads() {
		getDriver().findElement(By.linkText("Leads")).click();
       return new MyLeadsPage();
	}
	
	
}
