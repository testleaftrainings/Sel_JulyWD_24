package base;

public class LearnRandomNumber {

	public static void main(String[] args) {
		int randomNumber = (int) (Math.random()*9999999+99999999);
System.out.println(randomNumber);
	}

}
//0.8073864553344328
//0.2345366414764536

//103139138
//103150904