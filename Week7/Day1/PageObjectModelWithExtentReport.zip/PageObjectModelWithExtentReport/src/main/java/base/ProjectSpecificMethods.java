package base;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class ProjectSpecificMethods extends AbstractTestNGCucumberTests {
	public static ChromeDriver driver;
	public String fileName,testname,testdescription,testAuthor,testCategory;
	public static ExtentReports extent;
	public static ExtentTest test;
	
	@BeforeMethod
	public void preCondition() {
		driver=new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().window().maximize();

	}
	
	
	@DataProvider
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(fileName);

	}
	
@AfterMethod
	public void postCondition() {
		driver.close();

	}

@BeforeSuite
public void startReport() {
	
			ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/result.html");
            extent=new ExtentReports();
		    extent.attachReporter(reporter);

}


@BeforeClass
public void testcaseDetails() {
	test = extent.createTest(testname, testdescription);
	test.assignAuthor(testAuthor);
	test.assignCategory(testCategory);

}

public int takeSnapshot() throws IOException {
	int randomNumber = (int) (Math.random()*9999999+99999999);
	File source = driver.getScreenshotAs(OutputType.FILE);
	File destination=new File("./snaps/image"+randomNumber+".png");
	FileUtils.copyFile(source, destination);
	//System.out.println("Take");
	return randomNumber;
	

}

public void reportStep(String msg, String status) throws IOException {
	
	if (status.equalsIgnoreCase("pass")) {
		test.pass(msg, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnapshot()+".png").build());
	}
	
	else if(status.equalsIgnoreCase("fail")) {
		test.fail(msg);
	}

}

@AfterSuite
public void stopReport() {
	extent.flush();

}


}
