package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC_001CreateLead extends ProjectSpecificMethods {
	
	@Test
	public void runCreateLead() {
		
		LoginPage lp=new LoginPage();
		lp.enterUserame()
		.enterPassword()
		.clickLogin()
         .verifyLogin()
         .clickCrmsfa()
         .clickLeads()
         .clickCreateLeads()
         .enterCompanyname()
         .enterFirstname()
         .enterLastname()
         .clickCreateLeadsSubmitbutton()
         .verifyLead();
	}

}
