package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;

public class ViewLeadsPage extends ProjectSpecificMethods{
	
	public void verifyLead() {
		
		String firstNameText = driver.findElement(By.id("viewLead_firstName_sp")).getText();
               if (firstNameText.contains("Vineeth")) {
				System.out.println("Lead was created");
			}
               else {
            	   System.out.println("Lead was not created");
               }
	}

}
