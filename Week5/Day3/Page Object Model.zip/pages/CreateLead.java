package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;

public class CreateLead extends ProjectSpecificMethods{
	
	public CreateLead enterCompanyname() {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("TestLeaf");
        return this;
	}
	public CreateLead enterFirstname() {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Vineeth");
       return this;
	}
	public CreateLead enterLastname() {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("Rajendran");
        return this;
	}
	public ViewLeadsPage clickCreateLeadsSubmitbutton() {
		driver.findElement(By.name("submitButton")).click();
		return new ViewLeadsPage();

	}

}
