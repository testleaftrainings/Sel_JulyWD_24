package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinition extends BaseClass {
	
	
	
	@And("Enter the username as {string}")
	public void enterUsername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);

	}
	
	@And("Enter the password as {string}")
	public void enterPassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);

	}
	
	@When("Click on the Login button")
	public void clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();

	}
	
	@Then("It should navigate to the welcome page")
	public void verifyLogin() {
		String welcomeText = driver.findElement(By.xpath("//h2[text()='Welcome ']")).getText();

		if (welcomeText.contains("Welcome")) {
			System.out.println("The page was navigated");
		}
		else
		{
			System.out.println("The page was not navigated");
		}
		
	}
    @But("Error message should be displayed")
	public void ErrorMessage() {
		String errorText = driver.findElement(By.xpath("//p[text()='The Following Errors Occurred:']")).getText();
        if (errorText.contains("Errors")) {
			System.out.println("Error message is displayed");
		}
        else {
			System.out.println("Error message is not displayed");
		}
	}
	
	
}
